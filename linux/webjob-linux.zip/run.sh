#!/bin/bash
echo "Current system date and time:"
date
