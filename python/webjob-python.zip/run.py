import datetime

print("Current system date and time:")
now = datetime.datetime.now()
print(now.strftime("%Y-%m-%d %H:%M:%S"))
