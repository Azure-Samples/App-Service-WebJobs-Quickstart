<?php
// PHP script to print current system date and time
// To run: php run.php

echo "Current system date and time:\n";
echo date("Y-m-d H:i:s") . "\n";
?>
