#!/bin/bash

./run