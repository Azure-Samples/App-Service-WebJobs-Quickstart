#!/bin/bash

dotnet run.dll 